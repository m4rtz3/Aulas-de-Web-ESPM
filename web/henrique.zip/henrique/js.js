function digitado(digito) {
    let campoSenha = document.getElementById("senha");
    campoSenha.value += digito;
}

function validar() {
    let saida = document.getElementById("saida")
    let escrito = document.getElementById("senha").value

    if (escrito === "1234") {
        saida.innerHTML = "Senha correta. Acesso permitido!"
        saida.className = "sucesso"
    } else {
        saida.innerHTML = "Senha incorreta. Tente novamente."
        saida.className = "erro"
    }

    escrito = ""
    adicionaCampo()
}

document.getElementById("senha").addEventListener("keyup", digitado)
document.getElementById("validar").addEventListener("click", validar)